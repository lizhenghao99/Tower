﻿using UnityEngine;

namespace Werewolf.SpellIndicators.Demo {
  public class Character : MonoBehaviour {
    private SplatManager Splats;

    void Start() {
      Splats = GetComponentInChildren<SplatManager>();
    }

    void Update() {
      // Character movement
      if (Input.GetMouseButton(1))
        GetComponent<NavMeshAgent>().destination = Splat.Get3DMousePosition();

      // Hide Splat if Left Mouse Click
      if (Input.GetMouseButton(0))
        Splats.Cancel();

      if (Input.GetKeyDown(KeyCode.Q)) {
        Splats.Direction.Select();
        Splats.Direction.Scale = 5f;
      }

      if (Input.GetKeyDown(KeyCode.W)) {
        Splats.Cone.Select();
        Splats.Cone.Scale = 5f;
      }

      if (Input.GetKeyDown(KeyCode.E)) {
        Splats.Point.Select();
        Splats.Point.Scale = 5f;
        Splats.Point.Range = 5f;
      }

      if (Input.GetKeyDown(KeyCode.A)) {
        Splats.Direction.Select();
        Splats.Direction.Scale = 8f;
      }

      if (Input.GetKeyDown(KeyCode.S)) {
        Splats.Cone.Select();
        Splats.Cone.Scale = 8f;
      }

      if (Input.GetKeyDown(KeyCode.D)) {
        Splats.Point.Select();
        Splats.Point.Scale = 8f;
        Splats.Point.Range = 8f;
      }
    }
  }
}