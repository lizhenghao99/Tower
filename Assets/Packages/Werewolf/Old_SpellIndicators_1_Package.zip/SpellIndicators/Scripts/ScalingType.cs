﻿using UnityEngine;
using System.Collections;

namespace Werewolf.SpellIndicators {
  public enum ScalingType {
    None,
    LengthAndHeight,
    LengthOnly
  }
}