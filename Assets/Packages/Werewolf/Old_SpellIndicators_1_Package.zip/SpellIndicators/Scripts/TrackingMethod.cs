﻿using UnityEngine;
using System.Collections;

namespace Werewolf.SpellIndicators {
  public enum TrackingMethod {
    Facing,
    Moving,
    None
  }
}